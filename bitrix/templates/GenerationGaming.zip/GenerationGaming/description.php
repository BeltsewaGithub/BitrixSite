<?
$arTemplate = array (
  'NAME' => 'MainTemplate',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>